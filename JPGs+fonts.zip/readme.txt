The Shop. Free e-commerce PSD template has been created by Victoria Slavinskaya from iqdesign.me

The Shop is a free PSD template for multi purpose e-commerce store. It is a responsive, creative and fresh look design package of 34 awesome PSD 

Features:

- 34 PSD templates: 12 PSD desktop template files & 22 PSD mobile template files 
- Responsive design (760px and 320 px versions)
- Free Google Fonts
- Active and hover stats are included
- Easily customizable and fully layered pages
- Pixel Perfect
- 960px Grid System

The Shop is available for free for use in both personal and commercial projects. The Shop is licensed under Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by-sa/4.0/).
